import numpy as np

arr = np.zeros((5,5))   # Create an array of all zeros
print(arr)

ident = np.eye(2)       # Create a 2x2 identity matrix
print(ident)

randArr = np.random.random((2,2))  # Create an array filled with random values
print(randArr)


